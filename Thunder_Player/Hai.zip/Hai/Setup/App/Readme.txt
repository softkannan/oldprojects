#######################################################################

#
# Thunder Player Read Me File
#
# $Revision: 1.1
# $Author: K.Kannan
#

			Thank you for reading this!
                    
                           Reading makes you smart.
                     Smart people don't have dumb questions.
                If you still have problems, ask fellow users at 
                     Kannan_softdev@yahoo.com

-----------------------------------------------------------------------

1.What is Thunder player?

Thunder player is a program designed for fast, powerful Movie Viewing. And now Bug Fixed.

[NEW FEATURES]

1.3D Volume Control.
2.m3u playlist file support.
3.Edited Moive Playback.
4.Logo Setting.
5.Sound Effects.
6.Full Screen Control.
7.Full Play back Rate Control.
8.Full playlist support.
9.Diff Playback size.
10.Full VCD & ACD Support etc...

#######################################################################

2. System Requirements

If your computer can run Windows 95, it can probably run Thunder Player.  The following system components are highly recommended:

CPU: Pentium 90MHz or above
OS: Windows 95/98/98SE/NT/Me/2000/XP
RAM: 16MB or more
CD-ROM Drive: CD-ROM XA Capable, Double Speed or above  (*NOTE*)
Free hard disk capacity: 4MB or more
Graphics Capability: VGA or above, 32,000 Colors or above
MPEG Driver: ActiveMovie recommended

#######################################################################

3. Credits

Project leader	K.Kannan
Lead programmer	K.Kannan
Main artist	K.Kannan
QA coordinator	K.Kannan
About	        Muthu.A Kumaran

(grin)

Okay, now for some real thanks:

Muthu.A Kumaran for beta- (alpha-?) testing so many of my intermediate builds.
C.Rajesh Kumar for beta- (alpha-?) testing so many of my intermediate builds.
Anyone I've forgotten who has given me feedback on Thunder Player!

#######################################################################

4.License

I can be contacted at the email address Kannan_softdev@yahoo.com or Kannan_softdev@hotmail.com.     

Helpful bug reports, code snippets, and thoughts are welcome.  Anyone willing to write a manual is especially welcome!

Oh yeah, and then there's this stuff I should probably include:


Thunder player is copyright � 2000-2002 by K.Kannan, All Rights Reserved.  Thunder Player is released with NO WARRANTY and freely usable/distributable under the terms of the GNU General Public License (GPL).  It should have been included with Thunder player; if not, you may receive a copy by writing to the Free Software Foundation, Inc., 675 Mass Ave., Cambridge, MA 02139, USA.

Any trademarks mentioned here are the property of their owners. To the author's knowledge no trademark or patent infringement exists in this document or in the VirtualDub distribution; any such infringement is purely unintentional

                 Thank You for using our product.

						Regards,
						     K.Kannan

-----------------------------------------------------------------------

	Developed By

		K.Kannan,
		Department Of Computer Science,
		Maharaja Engg College,
		Avinashi (TK),	Coimbatore DT,
		Tamil Nadu, India.

	Tel : 04294-22991
     e-mail : kannan_softdev@yahoo.com
	www : http://www16.brinkster.com/tmchallenge/downloads/thunder/

#######################################################################