using System;

namespace Jama
{
    public class CorrespondencesAreSingularException : Exception
    {
    }
}
