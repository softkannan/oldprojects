namespace MSR.CVE.BackMaker.ImagePipeline
{
    internal interface SizedObject
    {
        long GetSize();
    }
}
