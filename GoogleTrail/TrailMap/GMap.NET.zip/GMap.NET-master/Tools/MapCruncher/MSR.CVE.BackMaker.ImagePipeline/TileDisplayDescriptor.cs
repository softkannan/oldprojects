using System.Drawing;

namespace MSR.CVE.BackMaker.ImagePipeline
{
    public struct TileDisplayDescriptor
    {
        public TileAddress tileAddress;
        public Rectangle paintLocation;
    }
}
