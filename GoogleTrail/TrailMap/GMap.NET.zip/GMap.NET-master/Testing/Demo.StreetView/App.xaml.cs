﻿using System.Windows;

namespace Demo.StreetView
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
