﻿using System.Windows;

namespace TemplatedBinding
{
    /// <summary>
    ///     Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
